package com.accenture.lkm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.bean.DateBean;
import com.accenture.lkm.bean.PurchaseBean;
import com.accenture.lkm.dao.ReportDao;

@Service
public class ReportServiceImpl implements ReportService {
	@Autowired
	ReportDao reportDao;
	public List<PurchaseBean> getRecordsByDate(DateBean dateBean) {
		
//		List<PurchaseBean> purchaseBeans=new ArrayList<>();
//		purchaseBeans=reportDao.getRecordsByDate(dateBean);
//		return purchaseBeans;
		return reportDao.getRecordsByDate(dateBean);
	}

}
