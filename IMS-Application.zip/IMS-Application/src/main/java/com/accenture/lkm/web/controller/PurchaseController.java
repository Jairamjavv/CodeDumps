package com.accenture.lkm.web.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.bean.MaterialCategoryBean;
import com.accenture.lkm.bean.MaterialTypeBean;
import com.accenture.lkm.bean.PurchaseBean;
import com.accenture.lkm.bean.UnitBean;
import com.accenture.lkm.bean.VendorBean;
import com.accenture.lkm.service.PurchaseServiceImpl;

@Controller
public class PurchaseController {
//	@Autowired
//	private PurchaseServiceImpl psi;

//	@RequestMapping(value = "/purchasePage", method = RequestMethod.POST)
//	public ModelAndView purchasePage() throws Exception {
//		ModelAndView mav = new ModelAndView();
//		mav.setViewName("purchasePage");
//		mav.addObject("purchaseBean", new PurchaseBean());
//		return mav;
//	}
//
//	@RequestMapping(value = "/purchaseEntry", method = RequestMethod.POST)
//	public ModelAndView addPurchaseEntry(@ModelAttribute("purchaseBean") PurchaseBean pBean) throws Exception{
//		ModelAndView mav = new ModelAndView();
//
//		mav.setViewName("success");
//		PurchaseBean pb = psi.addPurchase(pBean);
//		mav.addObject("resultPurchaseBean",
//				pb.getVendorName() + pb.getMaterialCategory() + pb.getMaterialType() + pb.getBrandName() + pb.getUnit()
//						+ pb.getQuantity() + pb.getPurchaseAmount() + pb.getPurchaseDate() + pb.getPurchaseId()
//						+ pb.getTransId());
//
//		return mav;
//	}
//
//	@ModelAttribute("vendorList")
//	public List<VendorBean> generateVendorList() throws Exception {
//		List<VendorBean> vendorList = vendorServiceConsumer.getVendorBeanList();
//		return vendorList;
//	}

//	@ModelAttribute("categoryList")
//	public List<MaterialCategoryBean> generateCategoryList() throws Exception {
//		List<MaterialCategoryBean> materialCategoryList;
//		materialCategoryList = materialCategoryConsumer.getMaterialCategoryBeanList();
//		return materialCategoryList;
//	}

//	@RequestMapping(value = "getUnitAndMaterial", method = RequestMethod.POST)
//	public ModelAndView generateUnitAndTypeList(@ModelAttribute("purchaseBean") PurchaseBean purchaseBean,
//			HttpSession session) throws Exception {
//	String id=purchaseBean.getMaterialCategory();
//	
//	
//	List<UnitBean> unitList = materialServiceConsumer.getUnitListById(id);
//	List<MaterialTypeBean> materialTypeList = materialServiceConsumer.getMaterialTypeById(id);	
//	
//	ModelAndView view =new ModelAndView("form");
//	view.addObject("unitList",unitList);
//	session.setAttribute("unitList",unitList);
//	view.addObject("materialTypeList",materialTypeList);	
//	session.setAttribute("materialTypeList",materialTypeList);
//	
//	return view;
//	}
}
