package com.accenture.lkm.entity;
//
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name="material_type")
//public class TypeEntity {
//	
//	@Id
//	String type_id;
//	String type_name;
//	String category_id;
//	public String getType_id() {
//		return type_id;
//	}
//	public void setType_id(String type_id) {
//		this.type_id = type_id;
//	}
//	public String getType_name() {
//		return type_name;
//	}
//	public void setType_name(String type_name) {
//		this.type_name = type_name;
//	}
//	public String getCategory_id() {
//		return category_id;
//	}
//	public void setCategory_id(String category_id) {
//		this.category_id = category_id;
//	}
//	
//	
//	}

