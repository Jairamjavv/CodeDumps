package com.accenture.lkm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accenture.lkm.bean.PurchaseBean;

import com.accenture.lkm.dao.PurchaseDao;

@Service
public class PurchaseServiceImpl implements PurchaseService {
	@Autowired
	PurchaseDao purchasedao;
	
	public PurchaseBean addPurchase(PurchaseBean purchaseBean) {
		PurchaseBean purchaseBean2=new PurchaseBean();
		purchaseBean2=purchasedao.addPurchase(purchaseBean);
		return purchaseBean2;
	}

}
