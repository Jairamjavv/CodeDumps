package com.accenture.lkm.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.PersistenceContext;
//import javax.persistence.Query;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

//import com.accenture.lkm.entity.PurchaseEntity;
import com.accenture.lkm.bean.DateBean;
import com.accenture.lkm.bean.PurchaseBean;

@Repository
public class ReportDaoImpl {
//	@Autowired
//	private EntityManagerFactory entityManagerFactory;
//
//	@PersistenceContext
//	private EntityManager entityManager;
//	public List<PurchaseBean> getRecordsByDate(DateBean dateBean) {
//		Date startDate = dateBean.getStartDate();
//		Date endDate = dateBean.getEndDate();
//		String name = dateBean.getVendorName();
//
//		Query query = null;
//		String b = "false";

		// if(start.equals("") && end.equals("")) {
		// b = "false";
		// }
		// else {
		// b = "true";
		// }
//
//		if (b.equals("true")) {
//			query = entityManager
//					.createQuery("select k from PurchaseEntity k where k.date>=?1 and k.date<=?2 and k.vendorName=?3");
//			query.setParameter(1, startDate);
//			query.setParameter(2, endDate);
//			query.setParameter(3, name);
//		} else {
//			query = entityManager.createQuery("select k from PurchaseEntity k where k.vendorName=:name");
//			query.setParameter("name", name);
//		}
//
//		List<PurchaseEntity> allListByDate = query.getResultList();
//		List<PurchaseBean> retList = new ArrayList<PurchaseBean>();
//		for (PurchaseEntity e : allListByDate) {
//			PurchaseBean bean = new PurchaseBean();
//			BeanUtils.copyProperties(e, bean);
//			retList.add(bean);
//
//		}
//
//		return retList;
//	}

}
