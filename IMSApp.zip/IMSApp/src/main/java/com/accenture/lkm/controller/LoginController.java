package com.accenture.lkm.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.servlet.ModelAndView;

import com.accenture.lkm.bean.LoginBean;
import com.accenture.lkm.dao.LoginDaoImpl;

@Controller
public class LoginController {
	@Autowired
	LoginDaoImpl loginDaoImpl;
	
	@RequestMapping("/login")
	public String loginForm(Model m) {
		m.addAttribute("loginBean", new LoginBean());
		return "LoginForm";
	}
}
