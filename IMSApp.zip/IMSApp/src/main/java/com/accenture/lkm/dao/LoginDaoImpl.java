package com.accenture.lkm.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.accenture.lkm.bean.LoginBean;

public class LoginDaoImpl {
	JdbcTemplate jdbcTemplate;
	
	public boolean loginValidate(LoginBean bean) {
		String sql = "Select password from login where username="+bean.getUserName()+"";
		List<LoginBean> list = jdbcTemplate.query(sql, new RowMapper<LoginBean>() {
			public LoginBean mapRow(ResultSet rs, int row) throws SQLException{
			LoginBean lb = new LoginBean();
			lb.setUserName(rs.getString(1));
			lb.setUserName(rs.getString(2));
			return lb;
			}
		});
		
		System.out.println(list.get(1));
		return true;
	}
}
